_A='%H:%M:%S'
import sys,subprocess
subprocess.call('pip install cfnresponse -t /tmp/ --no-cache-dir'.split(),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
sys.path.insert(1,'/tmp/')
import io,os,json,boto3,shutil,cfnresponse
from zipfile import ZipFile
from botocore.exceptions import ClientError as boto3_client_error
def zip_directory(path):
	for(B,F,C)in os.walk(path):
		for D in C:A=os.path.join(B,D);E=A[len(path)+len(os.sep):];yield(A,E)
def make_zip_file_bytes(path):
	A=io.BytesIO()
	with ZipFile(A,'w')as B:
		for(C,D)in zip_directory(path=path):B.write(C,D)
	return A.getvalue()
'\n    - Region | str\n    - Packages | list\n    - LayerName | str\n'
def handler(event,context):
	J='RequestType';I='ResourceProperties';G='LayerName';C=context;A=event;print(json.dumps(A));B=A[I]['Properties'];N=A[I]['Type'].replace('Custom::','');D={};K=boto3.Session(region_name=B['Region']);E=K.client('lambda')
	if A[J]in['Create','Update']:
		subprocess.call(('pip install '+' '.join(B['Packages'])+' -t /tmp/lambda-layer --no-cache-dir').split(),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);shutil.copyfile(os.path.realpath(__file__),'/tmp/lambda-layer/multi_region_db.py')
		try:H=E.publish_layer_version(LayerName=B[G],Content={'ZipFile':make_zip_file_bytes('/tmp/lambda-layer')},CompatibleRuntimes=['python3.9','python3.10','python3.11','python3.12'],CompatibleArchitectures=['x86_64','arm64']);return cfnresponse.send(A,C,cfnresponse.SUCCESS,D,H['LayerVersionArn'])
		except boto3_client_error as F:print('Failed to Deploy Lambda Layer: '+str(F.response));return cfnresponse.send(A,C,cfnresponse.FAILED,D)
	if A[J]in['Delete']:
		try:
			L=E.list_layer_versions(LayerName=B[G])
			for M in L['LayerVersions']:H=E.delete_layer_version(LayerName=B[G],VersionNumber=M['Version'])
		except boto3_client_error as F:print('Failed to Delete Layer Versions: '+str(F.response));return cfnresponse.send(A,C,cfnresponse.FAILED,D)
		return cfnresponse.send(A,C,cfnresponse.SUCCESS,D)
import dateutil.tz
from datetime import datetime
from datetime import timedelta
class Functions:
	def __init__(A):''
	def add_five_seconds(A,start_time):return(datetime.strptime(str(start_time),_A)+timedelta(seconds=5)).strftime(_A)
	def subtract_five_seconds(A,start_time):return(datetime.strptime(str(start_time),_A)+timedelta(seconds=-5)).strftime(_A)
	def add_time(B,label,data):
		A=label;C=dateutil.tz.gettz('US/Pacific');D=datetime.now(tz=C)
		while datetime.strptime(A[len(A)-1],_A)+timedelta(seconds=9)<datetime.strptime(D.strftime(_A),_A):A.pop(0);data.pop(0);A.append(B.add_five_seconds(A[len(A)-1]));data.append('0')
	'\n        Requires "REGIONAL_(APP|DEMO)_DB_SECRET_ARN" as an environment variable\n        \n        - db_identifier | str (App|Demo)\n    '
	def get_db_credentials(E,db_identifier):
		A=db_identifier;B=boto3.client('secretsmanager')
		try:C=B.get_secret_value(SecretId=os.environ['REGIONAL_'+A.upper()+'_DB_SECRET_ARN'])
		except boto3_client_error as D:raise Exception('Failed to Retrieve '+A+' Database Secret: '+str(D))
		else:return json.loads(C['SecretString'])
	'\n        fqdn | str\n        newValue | str\n        hostedZoneId | str\n        [ ttl | int ]\n        [ type | str ]\n    '
	def update_dns_record(C,fqdn,new_value,hosted_zone_id,ttl=1,record_type='CNAME'):
		A=boto3.client('route53')
		try:A.change_resource_record_sets(ChangeBatch={'Changes':[{'Action':'UPSERT','ResourceRecordSet':{'Name':fqdn,'ResourceRecords':[{'Value':new_value}],'TTL':ttl,'Type':record_type}}]},HostedZoneId=hosted_zone_id)
		except boto3_client_error as B:raise Exception('Failed to Update DNS Record: '+str(B))
		return True